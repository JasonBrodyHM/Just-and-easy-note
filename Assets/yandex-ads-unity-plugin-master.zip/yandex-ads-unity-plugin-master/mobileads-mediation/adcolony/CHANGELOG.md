# Change Log

## Version 2.4.0

#### Updated
* Supported Android Yandex Mobile Ads SDK version 5.4.0
* Supported Android AdColony adapter version 4.8.0.2

## Version 2.3.0

#### Updated
* Supported Android Yandex Mobile Ads SDK version 5.3.0
* Supported Android AdColony adapter version 4.8.0.1

## Version 2.2.1

#### Updated
* Supported Android Yandex Mobile Ads SDK version 5.2.1

## Version 2.2.0

#### Updated
* Supported Android Yandex Mobile Ads SDK version 5.2.0
* Supported Android AdColony adapter version 4.8.0.0
* Supported Android AdColony SDK version 4.8.0

## Version 2.0.0

#### Updated
* Supported Android Yandex Mobile Ads SDK version 5.0.0
* Supported Android AdColony adapter version 4.6.5.0
* Supported Android AdColony SDK version 4.6.5

## Version 1.0.0

#### Updated
* Supported Android Yandex Mobile Ads SDK version 4.4.0
* Supported Android AdColony adapter version 4.6.4.0
* Supported Android AdColony SDK version 4.6.4
