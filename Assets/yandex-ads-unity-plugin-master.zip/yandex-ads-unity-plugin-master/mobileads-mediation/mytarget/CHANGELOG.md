# Change Log

## Version 2.6.0

#### Updated
* Supported Android MyTarget adapter version 5.16.2.0
* Supported Android MyTarget SDK version 5.16.2
* Supported Android Yandex Mobile Ads SDK version 5.5.0
* Supported iOS MyTarget adapter version 5.17.1.0
* Supported iOS MyTarget SDK version 5.17.1
* Supported iOS Yandex Mobile Ads SDK version 5.4.0

## Version 2.5.0

#### Updated
* Supported iOS MyTarget adapter version 5.17.0.0
* Supported iOS MyTarget SDK version 5.17.0
* Supported iOS Yandex Mobile Ads SDK version 5.3.1

## Version 2.4.0

#### Updated
* Supported Android MyTarget adapter version 5.15.5.0
* Supported Android MyTarget SDK version 5.15.5
* Supported Android Yandex Mobile Ads SDK version 5.4.0

## Version 2.3.0

#### Updated
* Supported Android MyTarget adapter version 5.15.0.2
* Supported Android Yandex Mobile Ads SDK version 5.3.0
* Supported iOS MyTarget adapter version 5.15.2.1
* Supported iOS MyTarget SDK version 5.15.2
* Supported iOS Yandex Mobile Ads SDK version 5.2.1

## Version 2.2.1

#### Updated
* Supported Android Yandex Mobile Ads SDK version 5.2.1

## Version 2.2.0

#### Updated
* Supported Android MyTarget adapter version 5.15.0.1
* Supported Android Yandex Mobile Ads SDK version 5.2.0
* Supported iOS MyTarget adapter version 5.15.2.0
* Supported iOS MyTarget SDK version 5.15.2
* Supported iOS Yandex Mobile Ads SDK version 5.1.0

## Version 2.0.0

#### Updated
* Supported Android MyTarget adapter version 5.15.0.0
* Supported Android MyTarget SDK version 5.15.0
* Supported Android Yandex Mobile Ads SDK version 5.0.0
* Supported iOS MyTarget adapter version 5.15.1.0
* Supported iOS MyTarget SDK version 5.15.1
* Supported iOS Yandex Mobile Ads SDK version 5.0.0

## Version 1.1.0

#### Updated
* Supported Android MyTarget adapter version 5.12.3.0
* Supported Android MyTarget SDK version 5.12.3
* Supported Android Yandex Mobile Ads SDK version 4.4.0
* Supported iOS MyTarget adapter version 5.13.1.0
* Supported iOS MyTarget SDK version 5.13.1
* Supported iOS Yandex Mobile Ads SDK version 4.4.1

## Version 1.0.0

#### Updated
* Supported Android MyTarget adapter version 1.12.0
* Supported Android MyTarget SDK version 5.11.7
* Supported Android Yandex Mobile Ads SDK version 4.1.0
* Supported iOS MyTarget adapter version 0.21.0
* Supported iOS MyTarget SDK version 5.10.1
* Supported iOS Yandex Mobile Ads SDK version 4.1.2

## Version 0.6.0

#### Updated
* Supported Android MyTarget adapter version 1.10.0
* Supported Android MyTarget SDK version 5.9.1
* Supported Android Yandex Mobile Ads SDK version 3.0.0
* Supported iOS MyTarget adapter version 0.13.0
* Supported iOS MyTarget SDK version 5.7.5
* Supported iOS Yandex Mobile Ads SDK version 2.20.0

## Version 0.5.0

#### Updated
* Supported Android MyTarget adapter version 1.7.0
* Supported Android MyTarget SDK version 5.8.0
* Supported iOS MyTarget adapter version 0.9.0
