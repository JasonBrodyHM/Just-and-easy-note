# Change Log

## Version 2.6.0

#### Updated
* Supported Android Mintegral adapter version 16.3.11.0
* Supported Android Mintegral SDK version 16.3.11
* Supported Android Yandex Mobile Ads SDK version 5.5.0
* Supported iOS Mintegral adapter version 7.2.8.0
* Supported iOS Mintegral SDK version 7.2.8
* Supported iOS Yandex Mobile Ads SDK version 5.4.0

## Version 2.5.0

#### Updated
* Supported iOS Mintegral adapter version 7.2.6.0
* Supported iOS Yandex Mobile Ads SDK version 5.3.1

## Version 2.4.0

#### Updated
* Supported Android Mintegral adapter version 15.8.01.4
* Supported Android Yandex Mobile Ads SDK version 5.4.0

## Version 2.3.1

#### Updated
* Supported Android Mintegral adapter version 15.8.01.3

## Version 2.3.0

#### Updated
* Supported Android Mintegral adapter version 15.8.01.2
* Supported Android Yandex Mobile Ads SDK version 5.3.0
* Supported iOS Mintegral adapter version 7.1.9.0
* Supported iOS Mintegral SDK version 7.1.9
* Supported iOS Yandex Mobile Ads SDK version 5.2.1

## Version 2.2.1

#### Updated
* Supported Android Yandex Mobile Ads SDK version 5.2.1

## Version 2.2.0

#### Updated
* Supported Android Mintegral adapter version 15.8.01.1
* Supported Android Mintegral SDK version 15.8.01
* Supported Android Yandex Mobile Ads SDK version 5.2.0
* Supported iOS Mintegral adapter version 7.1.7.0
* Supported iOS Mintegral SDK version 7.1.7
* Supported iOS Yandex Mobile Ads SDK version 5.1.0
