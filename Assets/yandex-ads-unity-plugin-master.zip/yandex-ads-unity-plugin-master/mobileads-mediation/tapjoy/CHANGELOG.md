# Change Log

## Version 2.4.0

#### Updated
* Supported Android Tapjoy adapter version 12.10.0.2
* Supported Android Yandex Mobile Ads SDK version 5.4.0

## Version 2.3.0

#### Updated
* Supported Android Tapjoy adapter version 12.10.0.1
* Supported Android Yandex Mobile Ads SDK version 5.3.0


## Version 2.2.1

#### Updated
* Supported Android Yandex Mobile Ads SDK version 5.2.1

## Version 2.2.0

#### Updated
* Supported Android Tapjoy adapter version 12.10.0.0
* Supported Android Tapjoy SDK version 12.10.0
* Supported Android Yandex Mobile Ads SDK version 5.2.0

## Version 2.0.0

#### Updated
* Supported Android Tapjoy adapter version 12.9.0.0
* Supported Android Tapjoy SDK version 12.9.0
* Supported Android Yandex Mobile Ads SDK version 5.0.0

## Version 1.0.0

#### Updated
* Supported Android Tapjoy adapter version 12.8.1.0
* Supported Android Tapjoy SDK version 12.8.1
* Supported Android Yandex Mobile Ads SDK version 4.4.0
