# Change Log

## Version 2.5.0

#### Updated
* Supported Android Chartboost adapter version 9.1.1.0
* Supported Android Chartboost SDK version 9.1.1
* Supported Android Yandex Mobile Ads SDK version 5.5.0

## Version 2.4.0

#### Updated
* Supported Android Chartboost adapter version 9.0.0.0
* Supported Android Chartboost SDK version 9.0.0
* Supported Android Yandex Mobile Ads SDK version 5.4.0

## Version 2.3.0

#### Updated
* Supported Android Chartboost adapter version 8.3.1.2
* Supported Android Yandex Mobile Ads SDK version 5.3.0

## Version 2.2.1

#### Updated
* Supported Android Yandex Mobile Ads SDK version 5.2.1

## Version 2.2.0

#### Updated
* Supported Android Chartboost adapter version 8.3.1.1
* Supported Android Yandex Mobile Ads SDK version 5.2.0

## Version 2.0.0

#### Updated
* Supported Android Chartboost adapter version 8.3.1.0
* Supported Android Chartboost SDK version 8.3.1
* Supported Android Yandex Mobile Ads SDK version 5.0.0

## Version 1.0.0

#### Updated
* Supported Android Chartboost adapter version 8.2.1.0
* Supported Android Chartboost SDK version 8.2.1
* Supported Android Yandex Mobile Ads SDK version 4.4.0
