# Change Log

## Version 2.6.0

#### Updated
* Supported Android Yandex Mobile Ads SDK version 5.5.0
* Supported Android IronSource adapter version 5.5.0.0
* Supported iOS Yandex Mobile Ads SDK version 5.4.0
* Supported iOS IronSource adapter version 5.4.0.0

## Version 2.5.0

#### Updated
* Supported iOS Yandex Mobile Ads SDK version 5.3.1
* Supported iOS IronSource adapter version 5.3.0.0

## Version 2.4.0

#### Updated
* Supported Android Yandex Mobile Ads SDK version 5.4.0
* Supported Android IronSource adapter version 5.4.0.0

## Version 2.3.0

#### Updated
* Supported Android Yandex Mobile Ads SDK version 5.3.0
* Supported Android IronSource adapter version 5.3.0.0
* Supported iOS Yandex Mobile Ads SDK version 5.2.1
* Supported iOS IronSource adapter version 5.2.0.0

## Version 2.2.1

#### Updated
* Supported Android Yandex Mobile Ads SDK version 5.2.1

## Version 2.2.0

#### Updated
* Supported Android Yandex Mobile Ads SDK version 5.2.0
* Supported Android IronSource adapter version 5.2.0.0
* Supported iOS Yandex Mobile Ads SDK version 5.1.0
* Supported iOS IronSource adapter version 5.1.0.0

## Version 2.1.1

#### Updated
* Supported Android Yandex Mobile Ads SDK version 5.1.1
* Supported Android IronSource SDK version 7.2.1.1
* Supported Android IronSource adapter version 5.1.0.0

## Version 2.1.0

#### Updated
* Supported Android Yandex Mobile Ads SDK version 5.1.0
* Supported iOS Yandex Mobile Ads SDK version 5.0.2

## Version 2.0.0

#### Updated
* Supported Android Yandex Mobile Ads SDK version 5.0.0
* Supported Android IronSource SDK version 7.1.14
* Supported Android IronSource adapter version 5.0.0.0
* Supported iOS Yandex Mobile Ads SDK version 5.0.0
* Supported iOS IronSource SDK version 7.2.0
* Supported iOS IronSource adapter version 5.0.0.0
