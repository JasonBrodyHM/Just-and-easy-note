# Change Log

## Version 2.6.0

#### Added
* Supported Android MobileAds Mediation version 5.5.0.0
* Supported iOS MobileAds Mediation version 5.4.0.0

## Version 2.5.0

#### Added
* Supported iOS MobileAds Mediation version 5.3.1.0

## Version 2.4.0

#### Added
* Supported Android MobileAds Mediation version 5.4.0.0
* Supported iOS MobileAds Mediation version 5.2.1.0
