# Change Log
All notable changes to ChartBoost Adapter for Yandex Mobile Ads Mediation will be documented in this file.

## Version 9.1.1.0

#### Added
* Added support for ChartBoost sdk version 9.1.1
* Updated minimum supported ChartBoost sdk version to 9.1.1

## Version 9.0.0.0

#### Added
* Added support for ChartBoost SDK version 9.0.0
* Updated minimum supported ChartBoost SDK version to 9.0.0
* Added support for Yandex Mobile Ads SDK version 5.4.0
* Updated minimum supported Yandex Mobile Ads SDK version to 5.4.0
* Added COPPA Support

## Version 8.3.1.2

#### Added
* Added support for Yandex Mobile Ads SDK version 5.3.0
* Updated minimum supported Yandex Mobile Ads SDK version to 5.3.0

## Version 8.3.1.1

#### Added
* Added support for Yandex Mobile Ads SDK version 5.2.0
* Updated minimum supported Yandex Mobile Ads SDK version to 5.2.0

## Version 8.3.1.0

#### Added
* Added support for ChartBoost SDK version 8.3.1
* Updated minimum supported ChartBoost SDK version to 8.3.1
* Added support for Yandex Mobile Ads SDK version 5.0.0
* Updated minimum supported Yandex Mobile Ads SDK version to 5.0.0

## Version 8.2.1.0

#### Added
* Added support for ChartBoost SDK version 8.2.1
* Updated minimum supported ChartBoost SDK version to 8.2.1
* Added support for Yandex Mobile Ads SDK version 4.4.0
* Updated minimum supported Yandex Mobile Ads SDK version to 4.4.0
