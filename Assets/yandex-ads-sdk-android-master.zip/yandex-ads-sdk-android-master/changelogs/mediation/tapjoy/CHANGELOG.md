# Change Log
All notable changes to TapJoy Adapter for Yandex Mobile Ads Mediation will be documented in this file.

## Version 12.10.0.2

#### Added
* Added support for Yandex Mobile Ads SDK version 5.4.0
* Updated minimum supported Yandex Mobile Ads SDK version to 5.4.0
* Added COPPA Support

## Version 12.10.0.1

#### Added
* Added support for Yandex Mobile Ads SDK version 5.3.0
* Updated minimum supported Yandex Mobile Ads SDK version to 5.3.0

## Version 12.10.0.0

#### Added
* Added support for TapJoy SDK version 12.10.0
* Updated minimum supported TapJoy SDK version to 12.10.0
* Added support for Yandex Mobile Ads SDK version 5.2.0
* Updated minimum supported Yandex Mobile Ads SDK version to 5.2.0

## Version 12.9.0.0

#### Added
* Added support for TapJoy SDK version 12.9.0
* Updated minimum supported TapJoy SDK version to 12.9.0
* Added support for Yandex Mobile Ads SDK version 5.0.0
* Updated minimum supported Yandex Mobile Ads SDK version to 5.0.0

## Version 12.8.1.0

#### Added
* Added support for TapJoy SDK version 12.8.1
* Updated minimum supported TapJoy SDK version to 12.8.1
* Added support for Yandex Mobile Ads SDK version 4.4.0
* Updated minimum supported Yandex Mobile Ads SDK version to 4.4.0
