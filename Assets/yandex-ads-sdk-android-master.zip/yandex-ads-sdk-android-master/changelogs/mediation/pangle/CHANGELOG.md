# Change Log
All notable changes to Pangle Adapter for Yandex Mobile Ads Mediation will be documented in this file.

## Version 4.8.1.0.0

#### Added
* Added support for Pangle sdk version 4.8.1.0
* Updated minimum supported Pangle sdk version to 4.8.1.0

## Version 4.3.0.4.2

#### Added
* Added support for Yandex Mobile Ads SDK version 5.4.0
* Updated minimum supported Yandex Mobile Ads SDK version to 5.4.0
* Added COPPA Support

## Version 4.3.0.4.1

#### Added
* Added support for Yandex Mobile Ads SDK version 5.3.0
* Updated minimum supported Yandex Mobile Ads SDK version to 5.3.0

## Version 4.3.0.4.0

#### Added
* Added support for Pangle SDK version 4.3.0.4
* Updated minimum supported Pangle SDK version to 4.3.0.4
* Added support for Yandex Mobile Ads SDK version 5.2.0
* Updated minimum supported Yandex Mobile Ads SDK version to 5.2.0

## Version 4.1.1.8.0

#### Added
* Added support for Pangle SDK version 4.1.1.8
* Updated minimum supported Pangle SDK version to 4.1.1.8
* Added support for Yandex Mobile Ads SDK version 5.0.0
* Updated minimum supported Yandex Mobile Ads SDK version to 5.0.0

## Version 3.9.0.5.0

#### Added
* Added support for Pangle SDK version 3.9.0.5
* Updated minimum supported Pangle SDK version to 3.9.0.5
* Added support for Yandex Mobile Ads SDK version 4.4.0
* Updated minimum supported Yandex Mobile Ads SDK version to 4.4.0
